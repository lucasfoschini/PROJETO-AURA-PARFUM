using System.Diagnostics;
using AuraScent.Models;

namespace AuraScent.Services;

/// <summary>
/// Fachada de perfumes: Scento é a fonte principal; a 10ML só complementa (foto do frasco).
/// Implementa IPerfumeService, então HomeViewModel, ExploreViewModel e DetailViewModel
/// continuam iguais: basta trocar o registro no MauiProgram.
///
/// Plano B: se a 10ML falhar, demorar ou não tiver o perfume, o resultado é o da Scento,
/// já traduzido para português pelo dicionário PtBr (aplicado dentro do ScentoApiClient).
/// </summary>
public sealed class PerfumeCatalogService : IPerfumeService
{
    private static readonly TimeSpan TenMlTimeout = TimeSpan.FromSeconds(6);

    private readonly IPerfumeService _scento;
    private readonly ITenMlClient _tenMl;

    public PerfumeCatalogService(ScentoApiClient scento, ITenMlClient tenMl)
    {
        _scento = scento;
        _tenMl = tenMl;
    }

    public async Task<IReadOnlyList<PerfumeSummary>> SearchAsync(string term, CancellationToken ct = default)
    {
        // As duas consultas rodam em paralelo.
        var scentoTask = _scento.SearchAsync(term, ct);
        var tenMlTask = TrySearchTenMlAsync(term, ct);

        // Scento é a principal: se falhar, o ApiException segue para a tela (mensagem em português).
        var perfumes = await scentoTask;

        // 10ML nunca lança exceção (veja TrySearchTenMlAsync).
        var complements = await tenMlTask;
        if (complements.Count == 0) return perfumes;

        return perfumes.Select(p => Enrich(p, complements)).ToList();
    }

    // O detalhe (pirâmide de notas) continua vindo da Scento, já em português.
    public Task<PerfumeDetail> GetDetailAsync(PerfumeSummary summary, CancellationToken ct = default) =>
        _scento.GetDetailAsync(summary, ct);

    private static PerfumeSummary Enrich(PerfumeSummary perfume, IReadOnlyList<TenMlPerfume> candidates)
    {
        var match = PerfumeMatcher.FindBest(perfume, candidates);
        if (match is null) return perfume;

        return perfume with
        {
            ImageUrl = match.ImageUrl ?? perfume.ImageUrl,
            Family = string.IsNullOrWhiteSpace(perfume.Family) ? PtBr.Family(match.Family) : perfume.Family
        };
    }

    private async Task<IReadOnlyList<TenMlPerfume>> TrySearchTenMlAsync(string term, CancellationToken ct)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TenMlTimeout); // 10ML lenta nunca trava a tela

        try
        {
            return await _tenMl.SearchAsync(PtBr.SearchTerm(term), cts.Token);
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            Debug.WriteLine($"10ML indisponível, usando só a Scento: {ex.Message}");
            return Array.Empty<TenMlPerfume>();
        }
    }
}
