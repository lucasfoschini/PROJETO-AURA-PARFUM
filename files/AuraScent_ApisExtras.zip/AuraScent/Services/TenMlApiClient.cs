using System.Text.Json;

namespace AuraScent.Services;

/// <summary>Perfume como a 10ML o devolve (só o que o app usa).</summary>
public sealed record TenMlPerfume(string Name, string House, string Family, string? ImageUrl, string? PageUrl);

public interface ITenMlClient
{
    Task<IReadOnlyList<TenMlPerfume>> SearchAsync(string term, CancellationToken ct = default);
}

/// <summary>
/// 10ML Fragrance Index (gratuita, sem chave). Documentação: https://10ml.com/perfume-api
/// A API real fica em mcp.10ml.com (e não em 10ml.com).
/// Os nomes dos campos do JSON são lidos de forma tolerante: se algum não existir, vira null/"" e o app segue normal.
/// </summary>
public sealed class TenMlApiClient : ApiClientBase, ITenMlClient
{
    public const string BaseUrl = "https://mcp.10ml.com/api/v1/";

    // Nomes possíveis no JSON. CONFIRA em https://mcp.10ml.com/openapi.json e ajuste se precisar.
    private static readonly string[] ListKeys = { "perfumes", "results", "items", "data" };
    private static readonly string[] ImageKeys = { "image_url", "imageUrl", "image", "photo", "picture", "thumbnail" };

    protected override string ServiceName => "10ML";

    public TenMlApiClient(HttpClient http) : base(http) { }

    public async Task<IReadOnlyList<TenMlPerfume>> SearchAsync(string term, CancellationToken ct = default)
    {
        // locale=pt: na 10ML o idioma só muda os links do 10ml.com na resposta (nomes e notas continuam em inglês).
        using var doc = await GetJsonAsync($"perfumes?q={Uri.EscapeDataString(term)}&limit=20&locale=pt", ct);

        var list = new List<TenMlPerfume>();
        if (FindArray(doc.RootElement) is not { } array) return list;

        foreach (var item in array.EnumerateArray())
        {
            var name = item.Str("name");
            if (string.IsNullOrWhiteSpace(name)) continue;

            list.Add(new TenMlPerfume(
                name,
                Text(item, "house", "brand") ?? "",
                Text(item, "family") ?? "",
                AsHttpUrl(Text(item, ImageKeys)),
                AsHttpUrl(Text(item, "url", "link", "page"))));
        }
        return list;
    }

    private static JsonElement? FindArray(JsonElement root)
    {
        if (root.ValueKind == JsonValueKind.Array) return root;
        if (root.ValueKind != JsonValueKind.Object) return null;

        foreach (var key in ListKeys)
            if (root.Child(key) is { ValueKind: JsonValueKind.Array } known) return known;

        foreach (var prop in root.EnumerateObject())
            if (prop.Value.ValueKind == JsonValueKind.Array) return prop.Value;

        return null;
    }

    // Aceita "campo": "texto" ou "campo": { "name"/"url": "texto" }.
    private static string? Text(JsonElement item, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (item.Str(key) is { Length: > 0 } direct) return direct;
            if (item.Child(key) is { ValueKind: JsonValueKind.Object } obj)
            {
                var nested = obj.Str("name") ?? obj.Str("url");
                if (!string.IsNullOrWhiteSpace(nested)) return nested;
            }
        }
        return null;
    }

    private static string? AsHttpUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https") ? uri.ToString() : null;
}
