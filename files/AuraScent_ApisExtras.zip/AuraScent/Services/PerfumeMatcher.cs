using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using AuraScent.Models;

namespace AuraScent.Services;

/// <summary>
/// Faz a "igualação" entre um perfume da Scento e os candidatos da 10ML:
/// marca compatível + nome contido no outro, ignorando maiúsculas, acentos e
/// variações como "Eau de Parfum".
/// </summary>
public static class PerfumeMatcher
{
    // Quanto do nome maior o nome menor precisa cobrir para valer como "contido".
    // Evita casar "Sauvage" com "Sauvage Elixir" (são perfumes diferentes).
    private const double MinContainRatio = 0.6;

    private static readonly Regex Noise = new(
        @"\b(eau de parfum|eau de toilette|eau de cologne|extrait de parfum|parfum|extrait|edp|edt|edc)\b",
        RegexOptions.Compiled);

    private static readonly Regex HousePrefix = new(
        @"^(la maison|maison|parfums de|parfums|house of|the)\s+", RegexOptions.Compiled);

    public static TenMlPerfume? FindBest(PerfumeSummary target, IEnumerable<TenMlPerfume> candidates)
    {
        var house = NormalizeHouse(target.House);
        var name = NormalizeName(target.Name, house);
        if (name.Length == 0) return null;

        TenMlPerfume? best = null;
        var bestScore = 0;

        foreach (var candidate in candidates)
        {
            var candidateHouse = NormalizeHouse(candidate.House);
            var candidateName = NormalizeName(candidate.Name, candidateHouse);

            var score = NameScore(name, candidateName);
            if (score == 0) continue;

            var bothHouses = house.Length > 0 && candidateHouse.Length > 0;
            if (bothHouses && !SameHouse(house, candidateHouse)) continue;   // marcas diferentes: não é o mesmo perfume
            if (!bothHouses && score < 100) continue;                        // sem marca para conferir: só nome idêntico

            if (score > bestScore) { best = candidate; bestScore = score; }
        }
        return best;
    }

    private static int NameScore(string a, string b)
    {
        if (a.Length == 0 || b.Length == 0) return 0;
        if (a == b) return 100;

        var (shorter, longer) = a.Length <= b.Length ? (a, b) : (b, a);
        if (shorter.Length < 3 || !longer.Contains(shorter)) return 0;

        var ratio = (double)shorter.Length / longer.Length;
        return ratio >= MinContainRatio ? (int)(ratio * 90) : 0;
    }

    private static bool SameHouse(string a, string b) => a == b || a.Contains(b) || b.Contains(a);

    private static string NormalizeHouse(string? house)
    {
        var h = Fold(house);
        return HousePrefix.Replace(h, "").Trim();
    }

    private static string NormalizeName(string? name, string normalizedHouse)
    {
        var n = Collapse(Noise.Replace(Fold(name), " "));
        if (normalizedHouse.Length > 0 && n.StartsWith(normalizedHouse + " "))
            n = n[(normalizedHouse.Length + 1)..];
        return n.Trim();
    }

    // minúsculas, sem acentos, só letras/números e espaços simples
    private static string Fold(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        var decomposed = text.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(decomposed.Length);
        foreach (var c in decomposed)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
        }
        return Collapse(sb.ToString());
    }

    private static string Collapse(string s) => Regex.Replace(s, @"\s+", " ").Trim();
}
