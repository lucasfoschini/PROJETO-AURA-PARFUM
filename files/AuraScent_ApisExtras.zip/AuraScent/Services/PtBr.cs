using System.Globalization;
using System.Text;
using AuraScent.Models;

namespace AuraScent.Services;

/// <summary>
/// A Scento só devolve os dados em inglês (o parâmetro "lang" muda apenas links e rótulos).
/// Esta classe traduz para pt-BR o que a API devolve (notas, famílias, texto)
/// e converte o que o usuário digita em português para o inglês que a base entende.
/// </summary>
public static class PtBr
{
    // inglês (minúsculo) -> português. Frases completas têm prioridade sobre palavras soltas.
    private static readonly Dictionary<string, string> Terms = new(StringComparer.OrdinalIgnoreCase)
    {
        // cítricos
        ["bergamot"] = "bergamota", ["lemon"] = "limão", ["orange"] = "laranja", ["mandarin"] = "tangerina",
        ["mandarin orange"] = "tangerina", ["tangerine"] = "tangerina", ["grapefruit"] = "toranja",
        ["pink grapefruit"] = "toranja rosa", ["lime"] = "lima", ["neroli"] = "neroli", ["citrus"] = "cítricos",
        ["bitter orange"] = "laranja amarga", ["blood orange"] = "laranja sanguínea", ["sweet orange"] = "laranja doce",
        ["yuzu"] = "yuzu", ["kumquat"] = "kumquat", ["lemongrass"] = "capim-limão", ["verbena"] = "verbena",
        ["petitgrain"] = "petitgrain", ["orange blossom"] = "flor de laranjeira",
        // florais
        ["rose"] = "rosa", ["jasmine"] = "jasmim", ["jasmine sambac"] = "jasmim sambac", ["lavender"] = "lavanda",
        ["lavandin"] = "lavandim", ["violet"] = "violeta", ["iris"] = "íris", ["orris"] = "íris",
        ["orris root"] = "raiz de íris", ["peony"] = "peônia", ["lily of the valley"] = "lírio-do-vale",
        ["lily"] = "lírio", ["tuberose"] = "tuberosa", ["ylang-ylang"] = "ilangue-ilangue", ["ylang ylang"] = "ilangue-ilangue",
        ["geranium"] = "gerânio", ["magnolia"] = "magnólia", ["freesia"] = "frésia", ["carnation"] = "cravina",
        ["heliotrope"] = "heliotrópio", ["osmanthus"] = "osmanthus", ["gardenia"] = "gardênia",
        ["cherry blossom"] = "flor de cerejeira", ["lotus"] = "lótus", ["mimosa"] = "mimosa", ["orchid"] = "orquídea",
        ["lilac"] = "lilás", ["hyacinth"] = "jacinto", ["narcissus"] = "narciso", ["daffodil"] = "narciso",
        ["jonquil"] = "junquilho", ["water lily"] = "lírio-d'água", ["chamomile"] = "camomila", ["cyclamen"] = "ciclame",
        ["elderflower"] = "flor de sabugueiro", ["honeysuckle"] = "madressilva", ["sweet pea"] = "ervilha-de-cheiro",
        ["wisteria"] = "glicínia", ["tiare"] = "tiaré", ["frangipani"] = "frangipani", ["marigold"] = "calêndula",
        ["immortelle"] = "sempre-viva", ["white flowers"] = "flores brancas", ["flowers"] = "flores", ["flower"] = "flor",
        ["petals"] = "pétalas", ["floral"] = "floral", ["florals"] = "florais",
        // doces, resinas e fundos
        ["vanilla"] = "baunilha", ["amber"] = "âmbar", ["ambergris"] = "âmbar-gris", ["musk"] = "almíscar",
        ["white musk"] = "almíscar branco", ["tonka bean"] = "fava-tonka", ["tonka"] = "fava-tonka",
        ["tobacco"] = "tabaco", ["leather"] = "couro", ["suede"] = "camurça", ["incense"] = "incenso",
        ["frankincense"] = "olíbano", ["olibanum"] = "olíbano", ["myrrh"] = "mirra", ["benzoin"] = "benjoim",
        ["labdanum"] = "lábdano", ["balsam"] = "bálsamo", ["peru balsam"] = "bálsamo-do-peru", ["tolu balsam"] = "bálsamo-de-tolu",
        ["resin"] = "resina", ["styrax"] = "estoraque", ["opoponax"] = "opopanax", ["elemi"] = "elemi", ["galbanum"] = "gálbano",
        ["cistus"] = "cisto", ["coumarin"] = "cumarina", ["hay"] = "feno", ["aldehydes"] = "aldeídos",
        ["caramel"] = "caramelo", ["honey"] = "mel", ["praline"] = "praliné", ["sugar"] = "açúcar", ["cream"] = "creme",
        ["milk"] = "leite", ["butter"] = "manteiga", ["chocolate"] = "chocolate", ["cocoa"] = "cacau", ["coffee"] = "café",
        ["licorice"] = "alcaçuz", ["liquorice"] = "alcaçuz", ["powder"] = "pó", ["powdery"] = "talcado", ["rum"] = "rum",
        ["whisky"] = "uísque", ["whiskey"] = "uísque", ["cognac"] = "conhaque", ["wine"] = "vinho", ["champagne"] = "champanhe",
        // madeiras
        ["sandalwood"] = "sândalo", ["cedar"] = "cedro", ["cedarwood"] = "madeira de cedro", ["vetiver"] = "vetiver",
        ["patchouli"] = "patchouli", ["oud"] = "oud", ["agarwood"] = "madeira de agar", ["oakmoss"] = "musgo de carvalho",
        ["moss"] = "musgo", ["guaiac wood"] = "madeira de guaiaco", ["birch"] = "bétula", ["birch tar"] = "alcatrão de bétula",
        ["papyrus"] = "papiro", ["ebony"] = "ébano", ["rosewood"] = "pau-rosa", ["teak"] = "teca", ["oak"] = "carvalho",
        ["wood"] = "madeira", ["woods"] = "madeiras", ["woody"] = "amadeirado", ["woody notes"] = "notas amadeiradas",
        ["pine"] = "pinho", ["fir"] = "abeto", ["cypress"] = "cipreste", ["bamboo"] = "bambu", ["smoke"] = "fumaça",
        ["smoky"] = "esfumaçado",
        // especiarias e ervas
        ["cinnamon"] = "canela", ["clove"] = "cravo", ["cardamom"] = "cardamomo", ["nutmeg"] = "noz-moscada",
        ["saffron"] = "açafrão", ["pepper"] = "pimenta", ["black pepper"] = "pimenta-preta", ["pink pepper"] = "pimenta-rosa",
        ["ginger"] = "gengibre", ["coriander"] = "coentro", ["cumin"] = "cominho", ["anise"] = "anis",
        ["star anise"] = "anis-estrelado", ["juniper"] = "zimbro", ["cassia"] = "cássia", ["angelica"] = "angélica",
        ["mint"] = "hortelã", ["basil"] = "manjericão", ["sage"] = "sálvia", ["clary sage"] = "sálvia-esclareia",
        ["thyme"] = "tomilho", ["rosemary"] = "alecrim", ["eucalyptus"] = "eucalipto", ["spice"] = "especiarias",
        ["spices"] = "especiarias", ["spicy"] = "especiado", ["spice route"] = "rota das especiarias",
        // frutas e comidas
        ["peach"] = "pêssego", ["apple"] = "maçã", ["pear"] = "pera", ["plum"] = "ameixa", ["blackcurrant"] = "cassis",
        ["cassis"] = "cassis", ["raspberry"] = "framboesa", ["strawberry"] = "morango", ["blackberry"] = "amora",
        ["cherry"] = "cereja", ["fig"] = "figo", ["pineapple"] = "abacaxi", ["mango"] = "manga", ["melon"] = "melão",
        ["passion fruit"] = "maracujá", ["banana"] = "banana", ["apricot"] = "damasco", ["lychee"] = "lichia",
        ["pomegranate"] = "romã", ["grape"] = "uva", ["quince"] = "marmelo", ["rhubarb"] = "ruibarbo",
        ["watermelon"] = "melancia", ["coconut"] = "coco", ["almond"] = "amêndoa", ["pistachio"] = "pistache",
        ["hazelnut"] = "avelã", ["walnut"] = "noz", ["chestnut"] = "castanha", ["red fruits"] = "frutas vermelhas",
        ["fruits"] = "frutas", ["fruity"] = "frutado", ["fruit"] = "fruta", ["tea"] = "chá", ["green tea"] = "chá verde",
        ["black tea"] = "chá preto", ["cotton"] = "algodão",
        // verdes, aquáticos e outros
        ["green notes"] = "notas verdes", ["green"] = "verde", ["grass"] = "grama", ["cut grass"] = "grama cortada",
        ["leaves"] = "folhas", ["leaf"] = "folha", ["fig leaf"] = "folha de figo", ["violet leaf"] = "folha de violeta",
        ["ivy"] = "hera", ["sea notes"] = "notas marinhas", ["marine"] = "marinho", ["aquatic"] = "aquático",
        ["salt"] = "sal", ["ozone"] = "ozônio", ["rain"] = "chuva", ["water"] = "água", ["eau"] = "água",
        ["fresh"] = "fresco", ["musky"] = "almiscarado", ["sweet"] = "doce", ["oriental"] = "oriental",
        ["aromatic"] = "aromático", ["gourmand"] = "gourmand", ["chypre"] = "chipre", ["fougere"] = "fougère",
        ["fougère"] = "fougère", ["family"] = "família", ["notes"] = "notas", ["note"] = "nota",
        // linguagem usada nas famílias
        ["and"] = "e", ["of"] = "de", ["the"] = "o"
    };

    // português digitado (sem acento) -> inglês usado na busca da Scento
    private static readonly Dictionary<string, string> Reverse = BuildReverse();

    private static Dictionary<string, string> BuildReverse()
    {
        var map = new Dictionary<string, string>();
        foreach (var (en, pt) in Terms)
        {
            if (en is "and" or "of" or "the" or "eau" or "tea" or "fougere") continue;
            map.TryAdd(Normalize(pt), en.ToLowerInvariant());
        }

        // apelidos comuns em português
        map["citrico"] = "citrus"; map["citricos"] = "citrus"; map["citrica"] = "citrus";
        map["amadeirado"] = "woody"; map["amadeirada"] = "woody"; map["madeiras"] = "wood";
        map["floral"] = "floral"; map["flores"] = "floral"; map["florais"] = "floral";
        map["especiaria"] = "spice"; map["especiarias"] = "spice"; map["especiado"] = "spice";
        map["doce"] = "sweet"; map["frutado"] = "fruity"; map["fruta"] = "fruit"; map["frutas"] = "fruit";
        map["marinho"] = "marine"; map["aquatico"] = "aquatic"; map["fresco"] = "fresh";
        map["incenso"] = "incense"; map["cravo"] = "clove"; map["cha"] = "tea";
        return map;
    }

    /// <summary>Português digitado pelo usuário -> termo em inglês. Nomes de casas/perfumes passam sem mudar.</summary>
    public static string SearchTerm(string term)
    {
        var trimmed = term.Trim();
        return Reverse.TryGetValue(Normalize(trimmed), out var en) ? en : trimmed;
    }

    /// <summary>Nota olfativa em inglês -> português. O que não estiver no dicionário continua como veio.</summary>
    public static string Note(string raw) => Translate(raw);

    /// <summary>Família olfativa em inglês -> português.</summary>
    public static string Family(string raw) => string.IsNullOrWhiteSpace(raw) ? raw : Translate(raw);

    /// <summary>Texto descritivo em português, montado a partir dos dados já traduzidos.</summary>
    public static string Lede(PerfumeSummary summary, IReadOnlyList<NoteLayer> layers)
    {
        var sb = new StringBuilder();

        var head = string.IsNullOrWhiteSpace(summary.House)
            ? summary.Name
            : $"{summary.Name}, da casa {summary.House},";
        var family = string.IsNullOrWhiteSpace(summary.Family)
            ? ""
            : $" da família {Family(summary.Family).ToLowerInvariant()}";
        sb.Append($"{head} é uma fragrância{family}.");

        var parts = new List<string>();
        var top = NotesOf(layers, "Notas de topo");
        var heart = NotesOf(layers, "Notas de coração");
        var bottom = NotesOf(layers, "Notas de fundo");
        if (top is not null) parts.Add($"abre com {top}");
        if (heart is not null) parts.Add($"ganha corpo com {heart}");
        if (bottom is not null) parts.Add($"termina em {bottom}");
        if (parts.Count > 0) sb.Append($" Ela {JoinPt(parts)}.");

        return sb.ToString();
    }

    private static string? NotesOf(IReadOnlyList<NoteLayer> layers, string layerName)
    {
        var layer = layers.FirstOrDefault(l => l.Name == layerName);
        if (layer is null || layer.Notes.Count == 0) return null;
        return JoinPt(layer.Notes.Take(3).Select(n => n.ToLowerInvariant()));
    }

    private static string JoinPt(IEnumerable<string> items)
    {
        var list = items.ToList();
        return list.Count switch
        {
            0 => "",
            1 => list[0],
            2 => $"{list[0]} e {list[1]}",
            _ => $"{string.Join(", ", list.Take(list.Count - 1))} e {list[^1]}"
        };
    }

    private static string Translate(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return raw;
        var text = raw.Trim();

        // 1) frase inteira ("black pepper", "orange blossom")
        if (Terms.TryGetValue(text, out var phrase)) return Capitalize(phrase);

        // 2) palavra por palavra
        var tokens = text.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Select(t => Terms.TryGetValue(t, out var pt) ? pt : t);
        return Capitalize(string.Join(' ', tokens));
    }

    private static string Capitalize(string s) =>
        string.IsNullOrEmpty(s) ? s : char.ToUpperInvariant(s[0]) + s[1..];

    private static string Normalize(string s)
    {
        var decomposed = s.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(decomposed.Length);
        foreach (var c in decomposed)
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return sb.ToString().Normalize(NormalizationForm.FormC);
    }
}
